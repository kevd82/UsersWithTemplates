
from django.urls import path, include

urlpatterns = [
    path('', include("UTapp.urls"))
]
