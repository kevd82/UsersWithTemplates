from django.apps import AppConfig


class UtappConfig(AppConfig):
    name = 'UTapp'
